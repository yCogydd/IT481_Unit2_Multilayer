﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT481_Wright_Unit2GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void connect_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("connect_CLick() called...");
            connectStatus.Text = "Startup...";
            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                connectStatus.Text = "Connection Successful";
                connection.Close();
            }
            catch (Exception ex)
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void showTable_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("connect_Click() called...");

            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                connectStatus.Text = "Retrieving Records...";
                command.Connection = connection;
                command.CommandText = "select * from Customers";
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                connectStatus.Text = "Retrieval Successful!";

                connection.Close();
            }

            catch ( Exception ex )
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void count_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("count_CLick() called...");
            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                custCount.Text = "Counting Records...";
                command.Connection = connection;
                command.CommandText = "select count(*) from Customers";
                int count = (int)command.ExecuteScalar();
                custCount.Text = "Number of Customers: " + count;
                connection.Close();
            }

            catch (Exception ex)
            {
                custCount.Text = "Error, " + ex;
            }
        }

        private void showTable_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("showTable_Click() called...");

            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                connectStatus.Text = "Retrieving Records...";
                command.Connection = connection;
                command.CommandText = "select * from Customers";
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                connectStatus.Text = "Retrieval Successful!";

                connection.Close();
            }

            catch (Exception ex)
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void count_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("count_CLick() called...");
            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                custCount.Text = "Counting Records...";
                command.Connection = connection;
                command.CommandText = "select count(*) from Customers";
                int count = (int)command.ExecuteScalar();
                custCount.Text = "Number of Customers: " + count;
                connection.Close();
            }

            catch (Exception ex)
            {
                custCount.Text = "Error, " + ex;
            }
        }
    }
}
